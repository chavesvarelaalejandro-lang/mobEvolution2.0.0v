package com.mobevolution.skills;

import com.mobevolution.Config;
import com.mobevolution.MobEvolution;
import com.mobevolution.client.ClientSkillData;
import com.mobevolution.network.Network;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public class SkillEvents {

    @Mod.EventBusSubscriber(modid = MobEvolution.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class ModBus {
        @SubscribeEvent
        public static void registerCaps(RegisterCapabilitiesEvent e) {
            e.register(PlayerSkills.class);
        }
    }

    @SubscribeEvent
    public void attach(AttachCapabilitiesEvent<Entity> e) {
        if (e.getObject() instanceof Player) {
            e.addCapability(new ResourceLocation(MobEvolution.MODID, "skills"), new PlayerSkillsProvider());
        }
    }

    @SubscribeEvent
    public void clone(PlayerEvent.Clone e) {
        e.getOriginal().reviveCaps();
        e.getOriginal().getCapability(PlayerSkillsProvider.CAP).ifPresent(old ->
                e.getEntity().getCapability(PlayerSkillsProvider.CAP).ifPresent(neu -> neu.copyFrom(old)));
        e.getOriginal().invalidateCaps();
    }

    @SubscribeEvent
    public void login(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            refresh(sp);
            if (Config.SHOW_LOGIN_MESSAGE.get()) {
                String extra = sp.createCommandSourceStack().hasPermission(2)
                        ? " Administrador: /mobconfig (configuración por mob), /mobday <n> (cambiar el día) y /mobevolution nearby."
                        : "";
                sp.sendSystemMessage(Component.literal("[MobEvolution 2.0.0] cargado." + extra));
            }
        }
    }

    @SubscribeEvent
    public void respawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            refresh(sp);
            if (!e.isEndConquered()) sp.setHealth(sp.getMaxHealth());
        }
    }

    @SubscribeEvent
    public void dimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) refresh(sp);
    }

    /** Velocidad de minado: se calcula igual en cliente (usa los datos sincronizados) y en servidor. */
    @SubscribeEvent
    public void breakSpeed(PlayerEvent.BreakSpeed e) {
        Player p = e.getEntity();
        int lvl;
        if (p.level().isClientSide) {
            lvl = ClientSkillData.DATA.getLevel(Skill.MINING);
        } else {
            lvl = p.getCapability(PlayerSkillsProvider.CAP).map(s -> s.getLevel(Skill.MINING)).orElse(0);
        }
        if (lvl > 0) {
            e.setNewSpeed(e.getNewSpeed() * (float) (1.0 + Skill.MINING.perLevel * lvl));
        }
    }

    public static void refresh(ServerPlayer sp) {
        SkillEffects.apply(sp);
        Network.sync(sp);
    }
}
