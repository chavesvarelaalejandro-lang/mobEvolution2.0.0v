# MobEvolution 2.0.0 (Forge 1.20.1)

Subir TODO el contenido de esta carpeta a la RAIZ de un repositorio de GitHub
(build.gradle, settings.gradle, gradle.properties, .github, src ...).
El .jar compilado aparece en la pestana Actions -> ejecucion -> Artifacts -> mod-jar.

Configuracion en el juego: config/mobevolution-common.toml
Tecla del arbol de habilidades: K
