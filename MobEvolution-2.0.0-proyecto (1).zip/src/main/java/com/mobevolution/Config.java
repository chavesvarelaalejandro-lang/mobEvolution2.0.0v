package com.mobevolution;

import java.util.List;
import net.minecraftforge.common.ForgeConfigSpec;

public final class Config {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    // ---------- NIVEL DEL MOB ----------
    public static final ForgeConfigSpec.IntValue MAX_LEVEL = B
            .comment("Nivel maximo absoluto de un mob")
            .defineInRange("maxMobLevel", 100, 1, 1000);
    public static final ForgeConfigSpec.DoubleValue DAYS_PER_LEVEL = B
            .comment("Dias de juego necesarios para subir 1 nivel el MINIMO (2 -> dia 30 = nivel minimo 15)")
            .defineInRange("daysPerLevel", 2.0, 0.1, 10000.0);
    public static final ForgeConfigSpec.DoubleValue MAX_MULTIPLIER = B
            .comment("El nivel maximo posible del momento = minimo x este valor (3 -> minimo 15, maximo 45)")
            .defineInRange("maxLevelMultiplier", 3.0, 1.0, 20.0);
    public static final ForgeConfigSpec.DoubleValue UPPER_HALF_CHANCE = B
            .comment("Probabilidad de que un mob salga en la MITAD ALTA del intervalo (entre 30 y 45 si el rango es 15-45).",
                     "El resto sale cerca del minimo. Cuanto mas alto el nivel, mas raro: llegar al maximo es muy improbable.")
            .defineInRange("upperHalfChance", 0.10, 0.01, 0.5);
    public static final ForgeConfigSpec.IntValue NETHER_BONUS = B
            .comment("Niveles extra al MINIMO en el Nether (0 = igual que el Overworld)")
            .defineInRange("netherBonus", 0, 0, 1000);
    public static final ForgeConfigSpec.IntValue END_BONUS = B
            .comment("Niveles extra al MINIMO en el End")
            .defineInRange("endBonus", 0, 0, 1000);

    // ---------- COSTE DE LAS HABILIDADES ----------
    public static final ForgeConfigSpec.IntValue XP_COST = B
            .comment("Puntos de experiencia que se gastan por cada nivel de habilidad.",
                     "IMPORTANTE: en servidores multijugador pon el mismo valor en el servidor y en los clientes.")
            .defineInRange("xpCostPerSkillLevel", 150, 1, 100000);

    // ---------- CURVA DE ESTADISTICAS ----------
    public static final ForgeConfigSpec.DoubleValue EXPONENT = B
            .comment("bonus = coeficiente * (nivel-1)^exponente. 1.0 = lineal; 0.85 = se frena poco a poco")
            .defineInRange("curveExponent", 0.85, 0.3, 1.5);
    public static final ForgeConfigSpec.DoubleValue HEALTH_COEF = B
            .defineInRange("healthCoef", 0.06, 0.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue DAMAGE_COEF = B
            .defineInRange("damageCoef", 0.036, 0.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue SPEED_COEF = B
            .defineInRange("speedCoef", 0.0024, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue ARMOR_COEF = B
            .defineInRange("armorCoef", 0.12, 0.0, 10.0);

    public static final ForgeConfigSpec.DoubleValue MAX_HEALTH_MULT = B
            .comment("Topes duros").defineInRange("maxHealthMultiplier", 5.0, 1.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue MAX_DAMAGE_MULT = B
            .defineInRange("maxDamageMultiplier", 3.0, 1.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue MAX_SPEED_BONUS = B
            .comment("0.25 = +25%").defineInRange("maxSpeedBonus", 0.25, 0.0, 5.0);
    public static final ForgeConfigSpec.DoubleValue MAX_ARMOR_BONUS = B
            .defineInRange("maxArmorBonus", 8.0, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue XP_PER_LEVEL = B
            .comment("XP extra al matar por nivel (maximo x3 total)")
            .defineInRange("xpPerLevel", 0.04, 0.0, 10.0);

    // ---------- JEFES Y FILTROS ----------
    public static final ForgeConfigSpec.BooleanValue SCALE_BOSSES = B
            .comment("Escalar tambien jefes (tag forge:bosses)")
            .define("scaleBosses", true);
    public static final ForgeConfigSpec.DoubleValue BOSS_FACTOR = B
            .comment("Los jefes reciben solo esta fraccion del bonus de vida/dano/armadura")
            .defineInRange("bossStrengthFactor", 0.5, 0.0, 10.0);
    public static final ForgeConfigSpec.BooleanValue ONLY_HOSTILE = B
            .define("onlyHostile", true);
    public static final ForgeConfigSpec.BooleanValue SHOW_LEVEL_IN_NAME = B
            .comment("Mostrar [Lv.X] en el nombre (no se toca si ya tiene nombre propio)")
            .define("showLevelInName", true);
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> BLACKLIST = B
            .comment("Mobs que NO se escalan: 'modid:entidad' o 'modid:*' para todo un mod.")
            .defineListAllowEmpty("blacklist", List.of(), o -> o instanceof String);

    public static final ForgeConfigSpec SPEC = B.build();

    private Config() {}
}
