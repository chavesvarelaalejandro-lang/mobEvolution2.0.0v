package com.mobevolution;

import java.util.List;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.Tags;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingExperienceDropEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

public class MobScalingHandler {
    public static final String TAG_LEVEL = "mobevolution_level";
    public static final String TAG_DMG = "mobevolution_dmg";

    private static final UUID HEALTH_ID = UUID.fromString("a1b2c3d4-0001-4000-8000-00000000e001");
    private static final UUID OLD_DAMAGE_ID = UUID.fromString("a1b2c3d4-0002-4000-8000-00000000e002");
    private static final UUID SPEED_ID  = UUID.fromString("a1b2c3d4-0003-4000-8000-00000000e003");
    private static final UUID ARMOR_ID  = UUID.fromString("a1b2c3d4-0004-4000-8000-00000000e004");

    // ------------------------------------------------------------------ eventos

    @SubscribeEvent
    public void onJoin(EntityJoinLevelEvent event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (!(event.getEntity() instanceof Mob mob)) return;

        CompoundTag data = mob.getPersistentData();
        if (data.contains(TAG_LEVEL)) { // ya escalado: los modificadores permanentes se guardan solos
            AttributeInstance old = mob.getAttribute(Attributes.ATTACK_DAMAGE);
            if (old != null && old.getModifier(OLD_DAMAGE_ID) != null) old.removeModifier(OLD_DAMAGE_ID);
            return;
        }
        if (!shouldScale(mob)) return;

        int lvl = computeLevel(level, mob);
        data.putInt(TAG_LEVEL, lvl);
        applyStats(mob, lvl);

        if (Config.SHOW_LEVEL_IN_NAME.get() && !mob.hasCustomName()) {
            mob.setCustomName(Component.literal("[Lv." + lvl + "] ").append(mob.getType().getDescription()));
            mob.setCustomNameVisible(false);
        }
    }

    /**
     * El dano se escala aqui y no con un atributo: asi tambien funciona con arqueros, blazes, ghasts,
     * calaveras del Wither, el aliento del dragon... que no usan el atributo de dano.
     */
    @SubscribeEvent
    public void onHurt(LivingHurtEvent event) {
        Entity src = event.getSource().getEntity();
        if (src instanceof Mob attacker && attacker != event.getEntity()) {
            CompoundTag d = attacker.getPersistentData();
            if (d.contains(TAG_DMG)) event.setAmount((float) (event.getAmount() * d.getDouble(TAG_DMG)));
        }
    }

    @SubscribeEvent
    public void onXp(LivingExperienceDropEvent event) {
        CompoundTag data = event.getEntity().getPersistentData();
        if (!data.contains(TAG_LEVEL)) return;
        double mult = Math.min(3.0, 1.0 + (data.getInt(TAG_LEVEL) - 1) * Config.XP_PER_LEVEL.get());
        event.setDroppedExperience((int) Math.round(event.getDroppedExperience() * mult));
    }

    // ------------------------------------------------------------------ logica

    private static boolean isBoss(Mob mob) {
        return mob.getType().is(Tags.EntityTypes.BOSSES);
    }

    private boolean shouldScale(Mob mob) {
        boolean boss = isBoss(mob);
        if (boss && !Config.SCALE_BOSSES.get()) return false;
        if (!boss && Config.ONLY_HOSTILE.get() && !(mob instanceof Enemy)) return false;
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(mob.getType());
        if (id == null) return false;
        List<? extends String> bl = Config.BLACKLIST.get();
        return !(bl.contains(id.toString()) || bl.contains(id.getNamespace() + ":*"));
    }

    private int computeLevel(ServerLevel level, Mob mob) {
        // Dia del juego (el mismo contador que ves en F3; dormir cuenta)
        double days = level.getServer().overworld().getDayTime() / 24000.0;

        // Nivel MINIMO: sube 1 cada daysPerLevel dias (dia 30 con 2 dias/nivel -> 15)
        int min = Math.max(1, (int) (days / Config.DAYS_PER_LEVEL.get()));
        if (level.dimension() == Level.NETHER) min += Config.NETHER_BONUS.get();
        else if (level.dimension() == Level.END) min += Config.END_BONUS.get();

        // Nivel MAXIMO del momento: minimo x multiplicador (15 -> 45)
        int max = Math.max(min, (int) Math.ceil(min * Config.MAX_MULTIPLIER.get()));

        // Tirada sesgada hacia el minimo: r = u^k.
        // k se calcula para que P(r > 0.5) = upperHalfChance (por defecto 10%).
        double chance = Config.UPPER_HALF_CHANCE.get();
        double k = Math.log(0.5) / Math.log(1.0 - chance);
        double r = Math.pow(level.random.nextDouble(), k);
        int result = min + (int) Math.round((max - min) * r);

        return Math.max(1, Math.min(Config.MAX_LEVEL.get(), result));
    }

    private void applyStats(Mob mob, int lvl) {
        int n = lvl - 1;
        if (n <= 0) return;
        boolean boss = isBoss(mob);
        double f = boss ? Config.BOSS_FACTOR.get() : 1.0;
        double curve = Math.pow(n, Config.EXPONENT.get());

        double hp = Math.min(Config.HEALTH_COEF.get() * curve * f, Config.MAX_HEALTH_MULT.get() - 1.0);
        double dmg = Math.min(Config.DAMAGE_COEF.get() * curve * f, Config.MAX_DAMAGE_MULT.get() - 1.0);
        double armor = Math.min(Config.ARMOR_COEF.get() * curve * f, Config.MAX_ARMOR_BONUS.get());
        double speed = boss ? 0.0 : Math.min(Config.SPEED_COEF.get() * curve, Config.MAX_SPEED_BONUS.get());

        add(mob, Attributes.MAX_HEALTH, HEALTH_ID, "health", hp, Operation.MULTIPLY_TOTAL);
        add(mob, Attributes.MOVEMENT_SPEED, SPEED_ID, "speed", speed, Operation.MULTIPLY_TOTAL);
        add(mob, Attributes.ARMOR, ARMOR_ID, "armor", armor, Operation.ADDITION);
        mob.getPersistentData().putDouble(TAG_DMG, 1.0 + dmg);
        mob.setHealth(mob.getMaxHealth());
    }

    private void add(Mob mob, Attribute attr, UUID id, String name, double amount, Operation op) {
        AttributeInstance inst = mob.getAttribute(attr);
        if (inst == null || amount <= 0) return;
        if (inst.getModifier(id) != null) inst.removeModifier(id);
        inst.addPermanentModifier(new AttributeModifier(id, "mobevolution_" + name, amount, op));
    }
}
