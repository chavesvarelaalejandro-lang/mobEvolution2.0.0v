package com.mobevolution.network;

import com.mobevolution.Config;
import com.mobevolution.skills.PlayerSkillsProvider;
import com.mobevolution.skills.SkillEffects;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Cliente -> servidor: "Reset Skills". Devuelve toda la experiencia gastada. */
public class ResetPacket {
    public ResetPacket() {}

    public static void encode(ResetPacket m, FriendlyByteBuf b) {}

    public static ResetPacket decode(FriendlyByteBuf b) { return new ResetPacket(); }

    public static void handle(ResetPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp == null) return;
            sp.getCapability(PlayerSkillsProvider.CAP).ifPresent(s -> {
                int refund = s.totalLevels() * Config.XP_COST.get();
                if (refund <= 0) return;
                s.resetAll();
                sp.giveExperiencePoints(refund);
                SkillEffects.apply(sp);
                Network.sync(sp);
            });
        });
        ctx.get().setPacketHandled(true);
    }
}
