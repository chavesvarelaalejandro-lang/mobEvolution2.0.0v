package com.mobevolution.skills;

import java.util.Arrays;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.util.INBTSerializable;

public class PlayerSkills implements INBTSerializable<CompoundTag> {
    private final int[] levels = new int[Skill.values().length];

    public int getLevel(Skill s) { return levels[s.ordinal()]; }

    public int totalLevels() {
        int t = 0;
        for (int l : levels) t += l;
        return t;
    }

    /** Comprueba un reparto de niveles. Devuelve el total de niveles a comprar, o -1 si no es valido. */
    public int validate(int[] inc) {
        if (inc == null || inc.length != levels.length) return -1;
        long total = 0;
        for (Skill s : Skill.values()) {
            int v = inc[s.ordinal()];
            if (v < 0 || v > 1000) return -1;
            if (levels[s.ordinal()] + v > s.maxLevel) return -1;
            total += v;
        }
        return (int) total;
    }

    public void apply(int[] inc) {
        for (int i = 0; i < levels.length; i++) levels[i] += inc[i];
    }

    public void resetAll() { Arrays.fill(levels, 0); }

    public void copyFrom(PlayerSkills o) {
        System.arraycopy(o.levels, 0, levels, 0, levels.length);
    }

    @Override
    public CompoundTag serializeNBT() {
        CompoundTag t = new CompoundTag();
        for (Skill s : Skill.values()) t.putInt(s.name(), levels[s.ordinal()]);
        return t;
    }

    @Override
    public void deserializeNBT(CompoundTag t) {
        for (Skill s : Skill.values()) levels[s.ordinal()] = Math.min(t.getInt(s.name()), s.maxLevel);
    }
}
