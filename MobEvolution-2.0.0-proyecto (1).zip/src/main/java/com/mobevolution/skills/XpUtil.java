package com.mobevolution.skills;

import net.minecraft.world.entity.player.Player;

public final class XpUtil {
    private XpUtil() {}

    /** Puntos de experiencia totales reales del jugador (nivel + barra), igual en cliente y servidor. */
    public static int totalXp(Player p) {
        int l = p.experienceLevel;
        double base;
        if (l <= 16) base = l * l + 6.0 * l;
        else if (l <= 31) base = 2.5 * l * l - 40.5 * l + 360;
        else base = 4.5 * l * l - 162.5 * l + 2220;
        return (int) base + Math.round(p.experienceProgress * p.getXpNeededForNextLevel());
    }
}
