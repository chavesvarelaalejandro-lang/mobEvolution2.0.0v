package com.mobevolution.client;

import com.mobevolution.Config;
import com.mobevolution.network.ApplyPacket;
import com.mobevolution.network.Network;
import com.mobevolution.network.ResetPacket;
import com.mobevolution.skills.PlayerSkills;
import com.mobevolution.skills.Skill;
import com.mobevolution.skills.XpUtil;
import java.util.Arrays;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Interfaz del arbol de habilidades.
 * Los "+" solo reparten niveles de forma local; la experiencia no se gasta hasta pulsar "Confirmar cambios".
 * Clic derecho sobre una tarjeta quita un punto pendiente.
 */
public class SkillScreen extends Screen {
    private static final int CARD_H = 40, GAP = 6, PAD = 10, HEADER = 58;

    private final Skill[] skills = Skill.values();
    private final int[] pending = new int[skills.length];
    private final ItemStack[] icons = new ItemStack[skills.length];
    private final Button[] plus = new Button[skills.length];
    private Button confirm, cancel, reset;
    private int left, top, panelW, cardW, frameH;

    public SkillScreen() {
        super(Component.literal("Árbol de Habilidades"));
        for (int i = 0; i < skills.length; i++) icons[i] = new ItemStack(iconFor(skills[i]));
    }

    private static Item iconFor(Skill s) {
        return switch (s) {
            case VITALITY -> Items.GOLDEN_APPLE;
            case STRENGTH -> Items.IRON_SWORD;
            case AGILITY -> Items.LEATHER_BOOTS;
            case RESISTANCE -> Items.SHIELD;
            case LUCK -> Items.RABBIT_FOOT;
            case MINING -> Items.IRON_PICKAXE;
        };
    }

    private static int colorFor(Skill s) {
        return switch (s) {
            case VITALITY -> 0xFF5B7FD6;
            case STRENGTH -> 0xFFD65B4A;
            case AGILITY -> 0xFFC9B238;
            case RESISTANCE -> 0xFF9A7B5A;
            case LUCK -> 0xFF7A6AD6;
            case MINING -> 0xFF3FB0A0;
        };
    }

    private static int tint(int c) {
        int r = ((c >> 16) & 255) / 7 + 12, g = ((c >> 8) & 255) / 7 + 12, b = (c & 255) / 7 + 12;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private int cardX(int i) { return left + PAD + (i % 2) * (cardW + GAP); }
    private int cardY(int i) { return top + HEADER + PAD + (i / 2) * (CARD_H + GAP); }

    private int pendingTotal() {
        int t = 0;
        for (int v : pending) t += v;
        return t;
    }

    private int xpCost() { return Config.XP_COST.get(); }

    /** Experiencia que te queda despues de restar lo que has repartido (pendiente de confirmar). */
    private int available() {
        int xp = (this.minecraft == null || this.minecraft.player == null) ? 0 : XpUtil.totalXp(this.minecraft.player);
        return xp - pendingTotal() * xpCost();
    }

    private boolean canAdd(int i) {
        return available() >= xpCost() && ClientSkillData.DATA.getLevel(skills[i]) + pending[i] < skills[i].maxLevel;
    }

    @Override
    protected void init() {
        cardW = Math.max(130, Math.min(176, (this.width - 40 - GAP - 2 * PAD) / 2));
        panelW = 2 * PAD + 2 * cardW + GAP;
        int rows = (skills.length + 1) / 2;
        frameH = 2 * PAD + rows * CARD_H + (rows - 1) * GAP;
        int totalH = HEADER + frameH + 6 + 20;
        left = (this.width - panelW) / 2;
        top = Math.max(4, (this.height - totalH) / 2);

        for (int i = 0; i < skills.length; i++) {
            final int idx = i;
            plus[i] = addRenderableWidget(Button.builder(Component.literal("+"), b -> {
                if (canAdd(idx)) pending[idx]++;
            }).bounds(cardX(i) + cardW - 26, cardY(i) + 10, 20, 20).build());
        }

        int by = top + HEADER + frameH + 6;
        confirm = addRenderableWidget(Button.builder(Component.literal("Confirmar cambios"), b -> {
            Network.CHANNEL.sendToServer(new ApplyPacket(pending.clone()));
            onClose();
        }).bounds(this.width / 2 - 125, by, 120, 20).build());
        cancel = addRenderableWidget(Button.builder(Component.literal("Cancelar"), b -> onClose())
                .bounds(this.width / 2 + 5, by, 120, 20).build());
        reset = addRenderableWidget(Button.builder(Component.literal("Reset Skills"), b -> {
            Network.CHANNEL.sendToServer(new ResetPacket());
            Arrays.fill(pending, 0);
        }).bounds(left + panelW - 84, top + 4, 84, 20).build());
    }

    @Override
    public void tick() {
        PlayerSkills d = ClientSkillData.DATA;
        for (int i = 0; i < skills.length; i++) plus[i].active = canAdd(i);
        confirm.active = pendingTotal() > 0;
        reset.active = d.totalLevels() > 0;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 1) { // clic derecho: quitar un punto pendiente
            for (int i = 0; i < skills.length; i++) {
                if (mx >= cardX(i) && mx < cardX(i) + cardW && my >= cardY(i) && my < cardY(i) + CARD_H && pending[i] > 0) {
                    pending[i]--;
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    // ------------------------------------------------------------ dibujo

    private static void box(GuiGraphics g, int x, int y, int w, int h, int border, int fill) {
        g.fill(x, y, x + w, y + h, border);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, fill);
    }

    /** Dibuja el texto reduciendolo si no cabe en maxW. */
    private void drawFit(GuiGraphics g, Component c, int x, int y, int maxW) {
        int w = this.font.width(c);
        if (w <= maxW) {
            g.drawString(this.font, c, x, y, 0xFFFFFF, true);
            return;
        }
        float s = (float) maxW / w;
        g.pose().pushPose();
        g.pose().translate((float) x, (float) y + (1f - s) * 4f, 0f);
        g.pose().scale(s, s, 1f);
        g.drawString(this.font, c, 0, 0, 0xFFFFFF, true);
        g.pose().popPose();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderBackground(g);
        PlayerSkills d = ClientSkillData.DATA;

        // Titulo sobre "tablon" de madera
        float ts = 1.4f;
        int tw = (int) (this.font.width(this.title) * ts) + 20;
        box(g, left, top, tw, 26, 0xFF2B1B0E, 0xFF7A5430);
        g.fill(left + 2, top + 2, left + tw - 2, top + 3, 0xFF956A3C);
        g.pose().pushPose();
        g.pose().translate((float) (left + 10), (float) top + (26f - 8f * ts) / 2f, 0f);
        g.pose().scale(ts, ts, 1f);
        g.drawString(this.font, this.title, 0, 0, 0xFFFFD04A, true);
        g.pose().popPose();

        // Caja de puntos
        box(g, left, top + 29, 150, 25, 0xFF5A5A5A, 0xFF2E2E2E);
        MutableComponent l1 = Component.literal("Experiencia: ").withStyle(ChatFormatting.WHITE)
                .append(Component.literal(available() + " XP").withStyle(ChatFormatting.GOLD));
        drawFit(g, l1, left + 6, top + 33, 138);
        drawFit(g, Component.literal("Cada nivel cuesta " + xpCost() + " XP").withStyle(ChatFormatting.GRAY), left + 6, top + 43, 138);

        // Marco principal
        box(g, left, top + HEADER, panelW, frameH, 0xFF707070, 0xF0141414);
        g.fill(left + 3, top + HEADER + 3, left + panelW - 3, top + HEADER + 4, 0xFF2A2A2A);

        // Tarjetas
        for (int i = 0; i < skills.length; i++) {
            Skill s = skills[i];
            int x = cardX(i), y = cardY(i), col = colorFor(s);
            int lvl = d.getLevel(s), p = pending[i];

            box(g, x, y, cardW, CARD_H, col, tint(col));

            // icono
            box(g, x + 5, y + 6, 28, 28, col, 0xFF101010);
            g.renderItem(icons[i], x + 11, y + 12);

            // nombre y nivel
            MutableComponent name = Component.literal(s.displayName + ": ").withStyle(ChatFormatting.WHITE)
                    .append(Component.literal(String.valueOf(lvl)).withStyle(ChatFormatting.GRAY));
            if (p > 0) name.append(Component.literal(" +" + p).withStyle(ChatFormatting.GREEN));
            name.append(Component.literal(" / " + s.maxLevel).withStyle(ChatFormatting.GRAY));
            int textW = cardW - 38 - 30;
            drawFit(g, name, x + 38, y + 6, textW);

            // barra de progreso + porcentaje
            int bx = x + 38, by = y + 19, bw = textW - 26;
            g.fill(bx - 1, by - 1, bx + bw + 1, by + 5, 0xFF555555);
            g.fill(bx, by, bx + bw, by + 4, 0xFF000000);
            g.fill(bx, by, bx + bw * lvl / s.maxLevel, by + 4, col);
            if (p > 0) g.fill(bx + bw * lvl / s.maxLevel, by, bx + bw * (lvl + p) / s.maxLevel, by + 4, 0xFF55FF55);
            int pct = (int) Math.round(100.0 * (lvl + p) / s.maxLevel);
            drawFit(g, Component.literal(pct + "%").withStyle(ChatFormatting.GRAY), bx + bw + 4, by - 2, 24);

            // descripcion
            drawFit(g, Component.literal(s.description).withStyle(ChatFormatting.GRAY), x + 38, y + 27, textW);
        }

        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
