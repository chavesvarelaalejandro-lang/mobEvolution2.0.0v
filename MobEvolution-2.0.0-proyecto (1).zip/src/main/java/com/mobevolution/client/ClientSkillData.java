package com.mobevolution.client;

import com.mobevolution.skills.PlayerSkills;
import net.minecraft.nbt.CompoundTag;

public final class ClientSkillData {
    public static final PlayerSkills DATA = new PlayerSkills();

    private ClientSkillData() {}

    public static void set(CompoundTag tag) {
        if (tag != null) DATA.deserializeNBT(tag);
    }
}
