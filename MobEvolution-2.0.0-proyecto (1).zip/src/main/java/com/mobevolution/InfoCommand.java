package com.mobevolution;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.Comparator;
import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/** /mobevolution nearby -> lista los mobs cercanos con su id, nivel y tipo (normal / jefe). Sirve para diagnosticar. */
public class InfoCommand {

    @SubscribeEvent
    public void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("mobevolution")
                .then(Commands.literal("nearby").executes(ctx -> nearby(ctx.getSource()))));
    }

    private static int nearby(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        List<Mob> mobs = p.level().getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(40.0));
        mobs.sort(Comparator.comparingDouble((Mob m) -> m.distanceToSqr(p)));
        if (mobs.isEmpty()) {
            src.sendSuccess(() -> Component.literal("No hay mobs en 40 bloques."), false);
            return 0;
        }
        int shown = 0;
        for (Mob m : mobs) {
            if (shown++ >= 12) break;
            String line = MobScalingHandler.describe(m);
            src.sendSuccess(() -> Component.literal(line), false);
        }
        return mobs.size();
    }
}
