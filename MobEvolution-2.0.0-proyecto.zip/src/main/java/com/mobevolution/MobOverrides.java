package com.mobevolution;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Configuracion por mob editable en el juego (guardada en el mundo). -1 en un campo = usar el valor por defecto. */
public class MobOverrides extends SavedData {
    private static final String NAME = "mobevolution_overrides";

    public static class Values {
        public int maxLevel = -1;        // nivel maximo
        public double healthPct = -1;    // % de vida extra por nivel
        public double damagePct = -1;    // % de dano extra por nivel
    }

    private final Map<String, Values> map = new HashMap<>();

    public static MobOverrides get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(MobOverrides::load, MobOverrides::new, NAME);
    }

    public static MobOverrides load(CompoundTag tag) {
        MobOverrides o = new MobOverrides();
        o.map.putAll(parse(tag.getList("list", 10)));
        return o;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.put("list", toList());
        return tag;
    }

    public Values get(String id) { return map.get(id); }

    public void set(String id, Values v) {
        if (v == null) map.remove(id); else map.put(id, v);
        setDirty();
    }

    public ListTag toList() {
        ListTag list = new ListTag();
        for (Map.Entry<String, Values> e : map.entrySet()) {
            CompoundTag c = new CompoundTag();
            c.putString("id", e.getKey());
            c.putInt("max", e.getValue().maxLevel);
            c.putDouble("hp", e.getValue().healthPct);
            c.putDouble("dmg", e.getValue().damagePct);
            list.add(c);
        }
        return list;
    }

    public CompoundTag toTag() {
        CompoundTag t = new CompoundTag();
        t.put("list", toList());
        return t;
    }

    public static Map<String, Values> parse(ListTag list) {
        Map<String, Values> out = new HashMap<>();
        for (int i = 0; i < list.size(); i++) {
            CompoundTag c = list.getCompound(i);
            Values v = new Values();
            v.maxLevel = c.getInt("max");
            v.healthPct = c.getDouble("hp");
            v.damagePct = c.getDouble("dmg");
            out.put(c.getString("id"), v);
        }
        return out;
    }
}
