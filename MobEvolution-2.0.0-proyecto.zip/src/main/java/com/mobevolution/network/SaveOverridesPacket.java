package com.mobevolution.network;

import com.mobevolution.MobOverrides;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.registries.ForgeRegistries;

/** Cliente -> servidor: cambios de la configuracion por mob. El servidor comprueba permisos y valida cada valor. */
public class SaveOverridesPacket {
    public static class Entry {
        public final String id;
        public final int max;
        public final double hp, dmg;

        public Entry(String id, int max, double hp, double dmg) {
            this.id = id;
            this.max = max;
            this.hp = hp;
            this.dmg = dmg;
        }
    }

    private final List<Entry> entries;

    public SaveOverridesPacket(List<Entry> entries) { this.entries = entries; }

    public static void encode(SaveOverridesPacket m, FriendlyByteBuf b) {
        b.writeVarInt(m.entries.size());
        for (Entry e : m.entries) {
            b.writeUtf(e.id, 128);
            b.writeInt(e.max);
            b.writeDouble(e.hp);
            b.writeDouble(e.dmg);
        }
    }

    public static SaveOverridesPacket decode(FriendlyByteBuf b) {
        int n = b.readVarInt();
        if (n < 0 || n > 4096) throw new IllegalArgumentException("demasiadas entradas");
        List<Entry> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) list.add(new Entry(b.readUtf(128), b.readInt(), b.readDouble(), b.readDouble()));
        return new SaveOverridesPacket(list);
    }

    private static boolean validPct(double v) { return v == -1 || (v >= 0 && v <= 1000); }

    public static void handle(SaveOverridesPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp == null) return;
            if (!sp.createCommandSourceStack().hasPermission(2)) {
                sp.sendSystemMessage(Component.literal("No tienes permiso para cambiar la configuración de MobEvolution."));
                return;
            }
            MobOverrides store = MobOverrides.get(sp.server);
            int applied = 0;
            for (Entry e : m.entries) {
                ResourceLocation rl = ResourceLocation.tryParse(e.id);
                if (rl == null || !ForgeRegistries.ENTITY_TYPES.containsKey(rl)) continue;
                boolean maxOk = e.max == -1 || (e.max >= 1 && e.max <= 1000);
                if (!maxOk || !validPct(e.hp) || !validPct(e.dmg)) continue;
                if (e.max == -1 && e.hp == -1 && e.dmg == -1) {
                    store.set(rl.toString(), null);
                } else {
                    MobOverrides.Values v = new MobOverrides.Values();
                    v.maxLevel = e.max;
                    v.healthPct = e.hp;
                    v.damagePct = e.dmg;
                    store.set(rl.toString(), v);
                }
                applied++;
            }
            sp.sendSystemMessage(Component.literal("MobEvolution: configuración guardada (" + applied
                    + " mobs modificados). Se aplica a los mobs que aparezcan a partir de ahora."));
        });
        ctx.get().setPacketHandled(true);
    }
}
