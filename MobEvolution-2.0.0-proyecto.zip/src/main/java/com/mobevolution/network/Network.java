package com.mobevolution.network;

import com.mobevolution.Config;
import com.mobevolution.MobEvolution;
import com.mobevolution.MobOverrides;
import com.mobevolution.skills.PlayerSkillsProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Network {
    private static final String PROTOCOL = "3";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MobEvolution.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private Network() {}

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, ApplyPacket.class, ApplyPacket::encode, ApplyPacket::decode, ApplyPacket::handle);
        CHANNEL.registerMessage(id++, ResetPacket.class, ResetPacket::encode, ResetPacket::decode, ResetPacket::handle);
        CHANNEL.registerMessage(id++, SyncPacket.class, SyncPacket::encode, SyncPacket::decode, SyncPacket::handle);
        CHANNEL.registerMessage(id++, RequestConfigPacket.class, RequestConfigPacket::encode, RequestConfigPacket::decode, RequestConfigPacket::handle);
        CHANNEL.registerMessage(id++, ConfigDataPacket.class, ConfigDataPacket::encode, ConfigDataPacket::decode, ConfigDataPacket::handle);
        CHANNEL.registerMessage(id++, SaveOverridesPacket.class, SaveOverridesPacket::encode, SaveOverridesPacket::decode, SaveOverridesPacket::handle);
    }

    public static void sync(ServerPlayer sp) {
        sp.getCapability(PlayerSkillsProvider.CAP).ifPresent(s ->
                CHANNEL.send(PacketDistributor.PLAYER.with(() -> sp), new SyncPacket(s.serializeNBT())));
    }

    /** Envia los datos y abre la pantalla de configuracion en el cliente (el que llama ya comprobo los permisos). */
    public static void openConfig(ServerPlayer sp) {
        MobOverrides o = MobOverrides.get(sp.server);
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> sp), new ConfigDataPacket(
                o.toTag(), Config.HEALTH_COEF.get() * 100.0, Config.DAMAGE_COEF.get() * 100.0, Config.MAX_LEVEL.get()));
    }
}
