package com.mobevolution.network;

import com.mobevolution.client.ClientConfigData;
import java.util.function.Supplier;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Servidor -> cliente: datos de la configuracion y orden de abrir la pantalla. */
public class ConfigDataPacket {
    private final CompoundTag tag;
    private final double defHealthPct, defDamagePct;
    private final int defMaxLevel;

    public ConfigDataPacket(CompoundTag tag, double defHealthPct, double defDamagePct, int defMaxLevel) {
        this.tag = tag;
        this.defHealthPct = defHealthPct;
        this.defDamagePct = defDamagePct;
        this.defMaxLevel = defMaxLevel;
    }

    public static void encode(ConfigDataPacket m, FriendlyByteBuf b) {
        b.writeNbt(m.tag);
        b.writeDouble(m.defHealthPct);
        b.writeDouble(m.defDamagePct);
        b.writeVarInt(m.defMaxLevel);
    }

    public static ConfigDataPacket decode(FriendlyByteBuf b) {
        return new ConfigDataPacket(b.readNbt(), b.readDouble(), b.readDouble(), b.readVarInt());
    }

    public static void handle(ConfigDataPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                ClientConfigData.open(m.tag, m.defHealthPct, m.defDamagePct, m.defMaxLevel)));
        ctx.get().setPacketHandled(true);
    }
}
