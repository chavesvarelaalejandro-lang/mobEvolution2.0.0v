package com.mobevolution.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Cliente -> servidor: "quiero abrir la configuracion". Solo si eres administrador. */
public class RequestConfigPacket {
    public RequestConfigPacket() {}

    public static void encode(RequestConfigPacket m, FriendlyByteBuf b) {}

    public static RequestConfigPacket decode(FriendlyByteBuf b) { return new RequestConfigPacket(); }

    public static void handle(RequestConfigPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp == null) return;
            if (!sp.createCommandSourceStack().hasPermission(2)) {
                sp.sendSystemMessage(Component.literal("Necesitas ser administrador (o tener los trucos activados) para abrir la configuración de MobEvolution."));
                return;
            }
            Network.openConfig(sp);
        });
        ctx.get().setPacketHandled(true);
    }
}
