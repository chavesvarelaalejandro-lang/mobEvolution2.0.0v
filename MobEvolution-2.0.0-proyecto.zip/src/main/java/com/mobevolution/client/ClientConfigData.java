package com.mobevolution.client;

import com.mobevolution.MobOverrides;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;

public final class ClientConfigData {
    public static final Map<String, MobOverrides.Values> OVERRIDES = new HashMap<>();
    public static double defaultHealthPct, defaultDamagePct;
    public static int defaultMaxLevel;

    private ClientConfigData() {}

    public static void open(CompoundTag tag, double hp, double dmg, int maxLevel) {
        OVERRIDES.clear();
        if (tag != null) OVERRIDES.putAll(MobOverrides.parse(tag.getList("list", 10)));
        defaultHealthPct = hp;
        defaultDamagePct = dmg;
        defaultMaxLevel = maxLevel;
        Minecraft.getInstance().setScreen(new MobConfigScreen());
    }
}
