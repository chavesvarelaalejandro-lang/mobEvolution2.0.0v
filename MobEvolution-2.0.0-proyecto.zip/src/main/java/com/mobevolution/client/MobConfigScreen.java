package com.mobevolution.client;

import com.mobevolution.MobOverrides;
import com.mobevolution.network.Network;
import com.mobevolution.network.SaveOverridesPacket;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.DefaultAttributes;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Pantalla de administrador: lista de todos los mobs (Minecraft y mods) con
 * nivel maximo y % de vida / dano por nivel. Campo vacio = valor por defecto.
 */
public class MobConfigScreen extends Screen {
    private static final int ROW_H = 24, W_MAX = 44, W_PCT = 58, GAP = 4;

    private static class Row {
        final String id, name;
        String max, hp, dmg;

        Row(String id, String name, MobOverrides.Values v) {
            this.id = id;
            this.name = name;
            this.max = (v == null || v.maxLevel < 0) ? "" : String.valueOf(v.maxLevel);
            this.hp = fmt(v == null ? -1 : v.healthPct);
            this.dmg = fmt(v == null ? -1 : v.damagePct);
        }
    }

    private final List<Row> all = new ArrayList<>();
    private List<Row> filtered = new ArrayList<>();
    private final List<EditBox> rowBoxes = new ArrayList<>();
    private EditBox search;
    private int scroll = 0, visibleRows, left, top, panelW, listTop, xMax, xHp, xDmg, nameW;

    @SuppressWarnings("unchecked")
    public MobConfigScreen() {
        super(Component.literal("Configuración de MobEvolution (administrador)"));
        for (EntityType<?> t : ForgeRegistries.ENTITY_TYPES.getValues()) {
            if (t == EntityType.PLAYER || t == EntityType.ARMOR_STAND) continue;
            if (!DefaultAttributes.hasSupplier((EntityType<? extends LivingEntity>) t)) continue; // solo seres vivos con atributos (mobs)
            ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(t);
            if (id == null) continue;
            all.add(new Row(id.toString(), t.getDescription().getString(), ClientConfigData.OVERRIDES.get(id.toString())));
        }
        all.sort(Comparator.comparing((Row r) -> r.name.toLowerCase(Locale.ROOT)).thenComparing(r -> r.id));
        filtered = new ArrayList<>(all);
    }

    // ------------------------------------------------------------ utilidades

    private static String fmt(double d) {
        if (d < 0) return "";
        if (d == Math.rint(d)) return String.valueOf((long) d);
        return String.valueOf(Math.round(d * 100.0) / 100.0);
    }

    private static double parseD(String s) {
        if (s == null || s.isEmpty() || s.equals(".")) return -1;
        try { return Double.parseDouble(s); } catch (NumberFormatException e) { return -1; }
    }

    private static int parseI(String s) {
        if (s == null || s.isEmpty()) return -1;
        try { return Integer.parseInt(s); } catch (NumberFormatException e) { return -1; }
    }

    private void drawFit(GuiGraphics g, Component c, int x, int y, int maxW) {
        int w = this.font.width(c);
        if (w <= maxW) {
            g.drawString(this.font, c, x, y, 0xFFFFFF, true);
            return;
        }
        float s = (float) maxW / w;
        g.pose().pushPose();
        g.pose().translate((float) x, (float) y + (1f - s) * 4f, 0f);
        g.pose().scale(s, s, 1f);
        g.drawString(this.font, c, 0, 0, 0xFFFFFF, true);
        g.pose().popPose();
    }

    // ------------------------------------------------------------ construccion

    @Override
    protected void init() {
        panelW = Math.min(this.width - 20, 440);
        left = (this.width - panelW) / 2;
        top = 6;

        int xEnd = left + panelW - 14;
        xDmg = xEnd - W_PCT;
        xHp = xDmg - GAP - W_PCT;
        xMax = xHp - GAP - W_MAX;
        nameW = xMax - (left + 10) - 6;

        listTop = top + 66;
        int listBottom = this.height - 36;
        visibleRows = Math.max(1, (listBottom - listTop) / ROW_H);

        search = new EditBox(this.font, left + 8, top + 20, panelW - 16, 18, Component.literal("Buscar"));
        search.setHint(Component.literal("Buscar mob por nombre o id..."));
        search.setMaxLength(40);
        search.setResponder(s -> applyFilter(s));
        addRenderableWidget(search);

        int by = this.height - 30;
        addRenderableWidget(Button.builder(Component.literal("Guardar"), b -> save())
                .bounds(this.width / 2 - 115, by, 110, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Cancelar"), b -> onClose())
                .bounds(this.width / 2 + 5, by, 110, 20).build());

        applyFilter(search.getValue());
    }

    private void applyFilter(String q) {
        String f = q == null ? "" : q.toLowerCase(Locale.ROOT).trim();
        List<Row> out = new ArrayList<>();
        for (Row r : all) {
            if (f.isEmpty() || r.name.toLowerCase(Locale.ROOT).contains(f) || r.id.contains(f)) out.add(r);
        }
        filtered = out;
        scroll = 0;
        rebuildRows();
    }

    private void rebuildRows() {
        for (EditBox b : rowBoxes) removeWidget(b);
        rowBoxes.clear();
        for (int i = 0; i < visibleRows; i++) {
            int idx = scroll + i;
            if (idx >= filtered.size()) break;
            final Row r = filtered.get(idx);
            int y = listTop + i * ROW_H + 3;

            EditBox bMax = new EditBox(this.font, xMax, y, W_MAX, 18, Component.literal(""));
            bMax.setMaxLength(4);
            bMax.setFilter(s -> s.matches("[0-9]*"));
            bMax.setValue(r.max);
            bMax.setResponder(s -> r.max = s);
            bMax.setHint(Component.literal("def.").withStyle(ChatFormatting.DARK_GRAY));

            EditBox bHp = new EditBox(this.font, xHp, y, W_PCT, 18, Component.literal(""));
            bHp.setMaxLength(7);
            bHp.setFilter(s -> s.matches("[0-9]*\\.?[0-9]*"));
            bHp.setValue(r.hp);
            bHp.setResponder(s -> r.hp = s);
            bHp.setHint(Component.literal("def.").withStyle(ChatFormatting.DARK_GRAY));

            EditBox bDmg = new EditBox(this.font, xDmg, y, W_PCT, 18, Component.literal(""));
            bDmg.setMaxLength(7);
            bDmg.setFilter(s -> s.matches("[0-9]*\\.?[0-9]*"));
            bDmg.setValue(r.dmg);
            bDmg.setResponder(s -> r.dmg = s);
            bDmg.setHint(Component.literal("def.").withStyle(ChatFormatting.DARK_GRAY));

            for (EditBox b : new EditBox[] {bMax, bHp, bDmg}) {
                addRenderableWidget(b);
                rowBoxes.add(b);
            }
        }
    }

    private void save() {
        List<SaveOverridesPacket.Entry> changes = new ArrayList<>();
        for (Row r : all) {
            int max = parseI(r.max);
            double hp = parseD(r.hp), dmg = parseD(r.dmg);
            MobOverrides.Values o = ClientConfigData.OVERRIDES.get(r.id);
            int om = o == null ? -1 : o.maxLevel;
            double oh = o == null ? -1 : o.healthPct;
            double od = o == null ? -1 : o.damagePct;
            if (max != om || Math.abs(hp - oh) > 1e-9 || Math.abs(dmg - od) > 1e-9) {
                changes.add(new SaveOverridesPacket.Entry(r.id, max, hp, dmg));
            }
        }
        if (!changes.isEmpty()) Network.CHANNEL.sendToServer(new SaveOverridesPacket(changes));
        onClose();
    }

    // ------------------------------------------------------------ entrada

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        int maxScroll = Math.max(0, filtered.size() - visibleRows);
        int ns = Mth.clamp(scroll - (int) Math.signum(delta) * 3, 0, maxScroll);
        if (ns != scroll) {
            scroll = ns;
            rebuildRows();
        }
        return true;
    }

    // ------------------------------------------------------------ dibujo

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderBackground(g);
        g.fill(left - 1, top - 1, left + panelW + 1, this.height - 3, 0xFF707070);
        g.fill(left, top, left + panelW, this.height - 4, 0xF0141414);

        float ts = 1.2f;
        g.pose().pushPose();
        g.pose().translate((float) (left + 8), (float) (top + 6), 0f);
        g.pose().scale(ts, ts, 1f);
        g.drawString(this.font, this.title, 0, 0, 0xFFFFD04A, true);
        g.pose().popPose();

        String info = String.format(Locale.ROOT,
                "Por defecto: vida %.1f%%/nivel · daño %.1f%%/nivel · nivel máx. %d. Campo vacío = por defecto.",
                ClientConfigData.defaultHealthPct, ClientConfigData.defaultDamagePct, ClientConfigData.defaultMaxLevel);
        drawFit(g, Component.literal(info).withStyle(ChatFormatting.GRAY), left + 8, top + 42, panelW - 16);

        int hy = top + 54;
        drawFit(g, Component.literal("Mob").withStyle(ChatFormatting.GOLD), left + 10, hy, nameW);
        drawFit(g, Component.literal("Nivel máx.").withStyle(ChatFormatting.GOLD), xMax, hy, W_MAX);
        drawFit(g, Component.literal("Vida %/nivel").withStyle(ChatFormatting.GOLD), xHp, hy, W_PCT);
        drawFit(g, Component.literal("Daño %/nivel").withStyle(ChatFormatting.GOLD), xDmg, hy, W_PCT);

        for (int i = 0; i < visibleRows; i++) {
            int idx = scroll + i;
            if (idx >= filtered.size()) break;
            Row r = filtered.get(idx);
            int ry = listTop + i * ROW_H;
            if (i % 2 == 0) g.fill(left + 4, ry, left + panelW - 4, ry + ROW_H, 0x22FFFFFF);
            drawFit(g, Component.literal(r.name).withStyle(ChatFormatting.WHITE), left + 10, ry + 3, nameW);
            drawFit(g, Component.literal(r.id).withStyle(ChatFormatting.DARK_GRAY), left + 10, ry + 13, nameW);
        }

        if (filtered.isEmpty()) {
            g.drawString(this.font, "Ningún mob coincide con la búsqueda.", left + 10, listTop + 6, 0xAAAAAA, true);
        }

        // barra de desplazamiento
        if (filtered.size() > visibleRows) {
            int trackH = visibleRows * ROW_H;
            int thumbH = Math.max(12, trackH * visibleRows / filtered.size());
            int maxScroll = filtered.size() - visibleRows;
            int thumbY = listTop + (trackH - thumbH) * scroll / maxScroll;
            int sx = left + panelW - 10;
            g.fill(sx, listTop, sx + 4, listTop + trackH, 0xFF2A2A2A);
            g.fill(sx, thumbY, sx + 4, thumbY + thumbH, 0xFFA0A0A0);
        }

        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
