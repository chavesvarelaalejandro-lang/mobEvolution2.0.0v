package com.mobevolution;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Contador de dias PROPIO del mod, guardado dentro del mundo.
 * Solo suma tiempo hacia delante: si se retrocede el reloj (/time set day, /time set 0...) el contador no se reinicia.
 * Se puede fijar a mano con /mobevolution setday <dia>.
 */
public class WorldDays extends SavedData {
    private static final String NAME = "mobevolution_days";

    private long totalTicks = 0;
    private long lastDayTime = 0;
    private boolean initialized = false;

    public static WorldDays get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(WorldDays::load, WorldDays::new, NAME);
    }

    public static WorldDays load(CompoundTag tag) {
        WorldDays d = new WorldDays();
        d.totalTicks = tag.getLong("totalTicks");
        d.lastDayTime = tag.getLong("lastDayTime");
        d.initialized = tag.getBoolean("initialized");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putLong("totalTicks", totalTicks);
        tag.putLong("lastDayTime", lastDayTime);
        tag.putBoolean("initialized", initialized);
        return tag;
    }

    public double days() {
        return totalTicks / 24000.0;
    }

    /** Llamar con el dayTime actual del Overworld. */
    public void update(long dayTime) {
        if (!initialized) { // primera vez en este mundo: parte del reloj actual (el "Day" de F3)
            totalTicks = dayTime;
            lastDayTime = dayTime;
            initialized = true;
            setDirty();
            return;
        }
        long delta = dayTime - lastDayTime;
        if (delta > 0) totalTicks += delta; // dormir o el paso normal del tiempo suman; retroceder no resta
        if (delta != 0) {
            lastDayTime = dayTime;
            setDirty();
        }
    }

    public void setDays(long days) {
        totalTicks = days * 24000L;
        setDirty();
    }
}
