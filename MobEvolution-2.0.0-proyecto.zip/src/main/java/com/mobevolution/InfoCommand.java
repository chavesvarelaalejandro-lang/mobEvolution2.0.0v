package com.mobevolution;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mobevolution.network.Network;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.Comparator;
import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * /mobevolution nearby       -> mobs cercanos con su id, nivel y tipo
 * /mobevolution days         -> dia que lleva contado el mod y nivel minimo actual
 * /mobevolution setday <dia> -> fija el dia del mod (requiere permisos de operador / trucos)
 * /mobevolution config      -> abre la configuracion por mob (requiere permisos de operador / trucos)
 */
public class InfoCommand {

    @SubscribeEvent
    public void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("mobevolution")
                .then(Commands.literal("nearby").executes(ctx -> nearby(ctx.getSource())))
                .then(Commands.literal("days").executes(ctx -> days(ctx.getSource())))
                .then(Commands.literal("config").requires(s -> s.hasPermission(2))
                        .executes(ctx -> {
                            Network.openConfig(ctx.getSource().getPlayerOrException());
                            return 1;
                        }))
                .then(Commands.literal("setday").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("dia", IntegerArgumentType.integer(0, 100000))
                                .executes(ctx -> setDay(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "dia"))))));
    }

    private static int nearby(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        List<Mob> mobs = p.level().getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(40.0));
        mobs.sort(Comparator.comparingDouble((Mob m) -> m.distanceToSqr(p)));
        if (mobs.isEmpty()) {
            src.sendSuccess(() -> Component.literal("No hay mobs en 40 bloques."), false);
            return 0;
        }
        int shown = 0;
        for (Mob m : mobs) {
            if (shown++ >= 12) break;
            String line = MobScalingHandler.describe(m);
            src.sendSuccess(() -> Component.literal(line), false);
        }
        return mobs.size();
    }

    private static int days(CommandSourceStack src) {
        MinecraftServer server = src.getServer();
        WorldDays wd = WorldDays.get(server);
        long clock = server.overworld().getDayTime();
        wd.update(clock);
        int min = Math.max(1, (int) (wd.days() / Config.DAYS_PER_LEVEL.get()));
        String text = "Dia del mod: " + (int) wd.days() + " | Dia del reloj de Minecraft (F3): " + (clock / 24000L)
                + " | Nivel minimo de mobs ahora: " + min;
        src.sendSuccess(() -> Component.literal(text), false);
        return 1;
    }

    private static int setDay(CommandSourceStack src, int day) {
        MinecraftServer server = src.getServer();
        WorldDays wd = WorldDays.get(server);
        wd.update(server.overworld().getDayTime());
        wd.setDays(day);
        int min = Math.max(1, (int) (day / Config.DAYS_PER_LEVEL.get()));
        String text = "Dia del mod fijado en " + day + ". Nivel minimo de mobs ahora: " + min;
        src.sendSuccess(() -> Component.literal(text), true);
        return 1;
    }
}
