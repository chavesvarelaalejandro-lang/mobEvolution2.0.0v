package com.mobevolution;

import java.util.List;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.Tags;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingExperienceDropEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.server.ServerLifecycleHooks;

public class MobScalingHandler {
    public static final String TAG_LEVEL = "mobevolution_level";
    public static final String TAG_DMG = "mobevolution_dmg";

    private static final UUID HEALTH_ID = UUID.fromString("a1b2c3d4-0001-4000-8000-00000000e001");
    private static final UUID OLD_DAMAGE_ID = UUID.fromString("a1b2c3d4-0002-4000-8000-00000000e002");
    private static final UUID SPEED_ID  = UUID.fromString("a1b2c3d4-0003-4000-8000-00000000e003");
    private static final UUID ARMOR_ID  = UUID.fromString("a1b2c3d4-0004-4000-8000-00000000e004");

    /** Tipo de mob a efectos de nivel maximo. */
    private enum Kind { NORMAL, VANILLA_BOSS, MODDED_BOSS, STRONG_BOSS }

    // ------------------------------------------------------------------ eventos

    @SubscribeEvent
    public void onJoin(EntityJoinLevelEvent event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (!(event.getEntity() instanceof Mob mob)) return;

        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(mob.getType());
        if (id == null) return;
        // Configuracion por mob hecha en el juego (pantalla de administrador); null = valores por defecto
        MobOverrides.Values ov = MobOverrides.get(level.getServer()).get(id.toString());

        CompoundTag data = mob.getPersistentData();
        if (data.contains(TAG_LEVEL)) { // ya escalado: los modificadores permanentes se guardan solos
            migrate(mob, data, ov);
            return;
        }

        Kind kind = kindOf(mob);
        if (!shouldScale(mob, kind, id, ov)) return;

        int lvl = computeLevel(level, kind, ov);
        data.putInt(TAG_LEVEL, lvl);
        applyStats(mob, lvl, kind != Kind.NORMAL, true, ov);

        if (Config.SHOW_LEVEL_IN_NAME.get() && !mob.hasCustomName()) {
            mob.setCustomName(Component.literal("[Lv." + lvl + "] ").append(mob.getType().getDescription()));
            mob.setCustomNameVisible(false);
        }
    }

    /**
     * El dano se escala aqui y no con un atributo: asi tambien funciona con arqueros, blazes, ghasts,
     * calaveras del Wither, el aliento del dragon... que no usan el atributo de dano.
     */
    @SubscribeEvent
    public void onHurt(LivingHurtEvent event) {
        Entity src = event.getSource().getEntity();
        if (src instanceof Mob attacker && attacker != event.getEntity()) {
            CompoundTag d = attacker.getPersistentData();
            if (d.contains(TAG_DMG)) event.setAmount((float) (event.getAmount() * d.getDouble(TAG_DMG)));
        }
    }

    /** Mantiene al dia el contador de dias (una vez por segundo). */
    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.getTickCount() % 20 != 0) return;
        WorldDays.get(server).update(server.overworld().getDayTime());
    }

    @SubscribeEvent
    public void onXp(LivingExperienceDropEvent event) {
        CompoundTag data = event.getEntity().getPersistentData();
        if (!data.contains(TAG_LEVEL)) return;
        double mult = Math.min(3.0, 1.0 + (data.getInt(TAG_LEVEL) - 1) * Config.XP_PER_LEVEL.get());
        event.setDroppedExperience((int) Math.round(event.getDroppedExperience() * mult));
    }

    // ------------------------------------------------------------------ clasificacion

    private static boolean matches(List<? extends String> list, ResourceLocation id) {
        return list.contains(id.toString()) || list.contains(id.getNamespace() + ":*");
    }

    private static double baseHealth(Mob mob) {
        AttributeInstance hp = mob.getAttribute(Attributes.MAX_HEALTH);
        return hp == null ? 0.0 : hp.getBaseValue(); // valor base: no incluye nuestros modificadores
    }

    /**
     * Mob normal / jefe de Minecraft / jefe de mod / jefe de mod fuerte.
     * Solo cuentan como jefe los que tienen el tag forge:bosses o estan en limitedBosses;
     * sus subditos e invocaciones son mobs normales. La vida base solo decide el tope DENTRO de los jefes de mod.
     */
    private static Kind kindOf(Mob mob) {
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(mob.getType());
        if (id == null) return Kind.NORMAL;
        boolean listed = matches(Config.LIMITED_BOSSES.get(), id);
        boolean tagged = mob.getType().is(Tags.EntityTypes.BOSSES);
        if (!listed && !tagged) return Kind.NORMAL;

        boolean vanilla = id.getNamespace().equals("minecraft");
        if (vanilla && !listed) return Kind.VANILLA_BOSS; // Ender Dragon, Wither

        double threshold = Config.STRONG_BOSS_HEALTH.get();
        if (!vanilla && threshold > 0 && baseHealth(mob) > threshold) return Kind.STRONG_BOSS;
        return Kind.MODDED_BOSS; // jefes de mod normales y Warden
    }

    /** Texto para el comando /mobevolution nearby. */
    public static String describe(Mob mob) {
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(mob.getType());
        CompoundTag d = mob.getPersistentData();
        String lvl = d.contains(TAG_LEVEL) ? "Lv." + d.getInt(TAG_LEVEL) : "sin nivel";
        MinecraftServer server = mob.getServer();
        MobOverrides.Values ov = (server == null || id == null) ? null : MobOverrides.get(server).get(id.toString());
        Kind k = kindOf(mob);
        String tipo = (switch (k) {
            case VANILLA_BOSS -> "jefe de Minecraft";
            case MODDED_BOSS -> "jefe de mod";
            case STRONG_BOSS -> "jefe de mod fuerte";
            default -> "mob normal";
        }) + " (tope " + capFor(k, ov) + ")" + (ov != null ? " [personalizado]" : "");
        return id + " | " + lvl + " | vida base " + Math.round(baseHealth(mob)) + " | " + tipo;
    }

    /** Nivel maximo: el configurado en el juego para ese mob, o el de su tipo. */
    private static int capFor(Kind kind, MobOverrides.Values ov) {
        if (ov != null && ov.maxLevel > 0) return ov.maxLevel;
        int cap = switch (kind) {
            case VANILLA_BOSS -> Config.VANILLA_BOSS_MAX_LEVEL.get();
            case MODDED_BOSS -> Config.MODDED_BOSS_MAX_LEVEL.get();
            case STRONG_BOSS -> Config.STRONG_BOSS_MAX_LEVEL.get();
            default -> Config.MAX_LEVEL.get();
        };
        return Math.min(cap, Config.MAX_LEVEL.get());
    }

    private boolean shouldScale(Mob mob, Kind kind, ResourceLocation id, MobOverrides.Values ov) {
        if (matches(Config.BLACKLIST.get(), id)) return false;
        if (kind != Kind.NORMAL) return Config.SCALE_BOSSES.get();
        if (ov != null) return true; // un mob configurado a mano siempre se escala
        return !Config.ONLY_HOSTILE.get() || mob instanceof Enemy;
    }

    // ------------------------------------------------------------------ nivel y estadisticas

    private int computeLevel(ServerLevel level, Kind kind, MobOverrides.Values ov) {
        // Dias contados por el propio mod (no se reinician con /time set; se ajustan con /mobevolution setday)
        MinecraftServer server = level.getServer();
        WorldDays wd = WorldDays.get(server);
        wd.update(server.overworld().getDayTime());
        double days = wd.days();

        // Nivel MINIMO: sube 1 cada daysPerLevel dias (dia 30 con 2 dias/nivel -> 15)
        int min = Math.max(1, (int) (days / Config.DAYS_PER_LEVEL.get()));
        if (level.dimension() == Level.NETHER) min += Config.NETHER_BONUS.get();
        else if (level.dimension() == Level.END) min += Config.END_BONUS.get();

        // Nivel MAXIMO del momento: minimo x multiplicador (15 -> 45)
        int max = Math.max(min, (int) Math.ceil(min * Config.MAX_MULTIPLIER.get()));

        // Tirada sesgada hacia el minimo: r = u^k.
        // k se calcula para que P(r > 0.5) = upperHalfChance (por defecto 10%).
        double chance = Config.UPPER_HALF_CHANCE.get();
        double k = Math.log(0.5) / Math.log(1.0 - chance);
        double r = Math.pow(level.random.nextDouble(), k);
        int result = min + (int) Math.round((max - min) * r);

        return Math.max(1, Math.min(capFor(kind, ov), result));
    }

    private void applyStats(Mob mob, int lvl, boolean boss, boolean heal, MobOverrides.Values ov) {
        int n = lvl - 1;
        if (n <= 0) return;
        double f = boss ? Config.BOSS_FACTOR.get() : 1.0;
        double curve = Math.pow(n, Config.EXPONENT.get());

        // Si el mob tiene valores propios (pantalla de administrador) se usan tal cual; si no, los globales
        double hpCoef = Config.HEALTH_COEF.get() * f;
        double dmgCoef = Config.DAMAGE_COEF.get() * f;
        if (ov != null && ov.healthPct >= 0) hpCoef = ov.healthPct / 100.0;
        if (ov != null && ov.damagePct >= 0) dmgCoef = ov.damagePct / 100.0;

        double hp = Math.min(hpCoef * curve, Config.MAX_HEALTH_MULT.get() - 1.0);
        double dmg = Math.min(dmgCoef * curve, Config.MAX_DAMAGE_MULT.get() - 1.0);
        double armor = Math.min(Config.ARMOR_COEF.get() * curve * f, Config.MAX_ARMOR_BONUS.get());
        double speed = boss ? 0.0 : Math.min(Config.SPEED_COEF.get() * curve, Config.MAX_SPEED_BONUS.get());

        add(mob, Attributes.MAX_HEALTH, HEALTH_ID, "health", hp, Operation.MULTIPLY_TOTAL);
        add(mob, Attributes.MOVEMENT_SPEED, SPEED_ID, "speed", speed, Operation.MULTIPLY_TOTAL);
        add(mob, Attributes.ARMOR, ARMOR_ID, "armor", armor, Operation.ADDITION);
        mob.getPersistentData().putDouble(TAG_DMG, 1.0 + dmg);
        if (heal) mob.setHealth(mob.getMaxHealth());
    }

    private void add(Mob mob, Attribute attr, UUID id, String name, double amount, Operation op) {
        AttributeInstance inst = mob.getAttribute(attr);
        if (inst == null || amount <= 0) return;
        if (inst.getModifier(id) != null) inst.removeModifier(id);
        inst.addPermanentModifier(new AttributeModifier(id, "mobevolution_" + name, amount, op));
    }

    private void remove(Mob mob, Attribute attr, UUID id) {
        AttributeInstance inst = mob.getAttribute(attr);
        if (inst != null && inst.getModifier(id) != null) inst.removeModifier(id);
    }

    /**
     * Mobs ya escalados que se cargan de nuevo: se limpia el modificador de dano antiguo y, si su nivel
     * supera el tope actual (jefes, o un nivel maximo configurado en el juego), se le baja al tope
     * conservando su proporcion de vida.
     */
    private void migrate(Mob mob, CompoundTag data, MobOverrides.Values ov) {
        remove(mob, Attributes.ATTACK_DAMAGE, OLD_DAMAGE_ID);

        Kind kind = kindOf(mob);
        if (kind == Kind.NORMAL && ov == null) return;
        int cap = capFor(kind, ov);
        if (data.getInt(TAG_LEVEL) <= cap) return;

        float maxBefore = mob.getMaxHealth();
        float ratio = maxBefore > 0 ? mob.getHealth() / maxBefore : 1f;

        remove(mob, Attributes.MAX_HEALTH, HEALTH_ID);
        remove(mob, Attributes.MOVEMENT_SPEED, SPEED_ID);
        remove(mob, Attributes.ARMOR, ARMOR_ID);
        data.remove(TAG_DMG);
        data.putInt(TAG_LEVEL, cap);
        applyStats(mob, cap, kind != Kind.NORMAL, false, ov);
        mob.setHealth(Math.max(0.5f, ratio * mob.getMaxHealth()));

        if (mob.hasCustomName() && mob.getCustomName().getString().startsWith("[Lv.")) {
            mob.setCustomName(Component.literal("[Lv." + cap + "] ").append(mob.getType().getDescription()));
        }
    }
}
